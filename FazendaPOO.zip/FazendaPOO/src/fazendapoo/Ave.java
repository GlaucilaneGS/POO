/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fazendapoo;

/**
 *
 * @author Glau
 */
public abstract class Ave extends Animal {

    
    private String corPena;
/**
     * @ metodo construtor
     */ 
    public Ave(int idade, double tamanho, String corPena) {
        super(idade, tamanho);
        this.corPena = corPena;
    }
     /**
     * @ assinaturas getters e setters 
     */
 
    public String getCorPena() {
        return corPena;
    }
    public void setCorPena(String corPena) {
        this.corPena = corPena;
    }

    /**
     * @ metodo que invocado as suas classes herdeiras 
     */
    public abstract void ChocarOvo();
    
}
