/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fazendapoo;



/**
 *
 * @author Glau
 */
public class Galinha extends Ave {
    
   
    public Galinha(int idade, double tamanho, String corPena) {
        super(idade, tamanho, corPena);
    }
    
    
     /**
     * metodo de entrada de dados 
     */
    public void DadosGalinha(){
        System.out.println("\n");
        System.out.println("***Animal cadastrado com sucesso!***");
        System.out.println("\n");
        System.out.println("A idade da galinha é " + this.getIdade() + " anos.");
        System.out.println("O tamanho da galinha é " + this.getTamanho() + " centímetros.");
        System.out.println("A cor da galinha é " + this.getCorPena() + ".");
    }
    
     /**
     * sobreescrita dos metodos  
     */
    
    @Override
    public void ChocarOvo() {
         System.out.print("Chocando Ovos.\n");
    }
     /**
     * sobreescrita dos metodos  
     */
     
    @Override
    public void talk() {
         System.out.print("cacarejando\n");
    }
    
    
}  
    

