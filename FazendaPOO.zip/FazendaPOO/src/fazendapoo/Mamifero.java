/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fazendapoo;

/**
 *
 * @author Glau
 */
public abstract  class  Mamifero extends Animal{
    
    private String corPelo;

    public Mamifero(int idade, double tamanho, String corPelo) {
        super(idade, tamanho);
        this.corPelo=corPelo; 
        
    }
     
    /** 
     * @ assinaturas getters e setters 
     */
     
    public String getcorPelo(){
    
        return corPelo;
    }
    
    public void setcorPelo(String corPelo){
        this.corPelo=corPelo;
        
    }
        
        /**
     * @ metodo mamiferos que herdaram nas supclasses
     */
    public abstract  void amamentar();
        
    } 

    

