/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fazendapoo;

/**
 *
 * @author Glau
 */
public  class Morcego extends Mamifero implements Voar {

    private int altitude;
    
    public Morcego(int idade,double tamanho,String corPelo,int altitude){
        super(idade, tamanho, corPelo);
        this.altitude = altitude;
    }

    /**
     * assinaturas getters e setters 
     * @return 
     */
    public int getAltitude() {
        return altitude;
    }

    /**
     * @param altitude the altitude to set
     */
    public void setAltitude(int altitude) {
        this.altitude = altitude;
    }
     /**
      * método para informar ao usuario os dados de cada variavel
      */
    public void DadosMorcego(){
        System.out.println("\n");
        System.out.println("***Novo animal cadastrado com sucesso!***");
        System.out.println("\n");
        System.out.println("A idade do morcego é " + this.getIdade() + " anos.");
        System.out.println("O tamanho do morcego é " + this.getTamanho() + " centímetros.");
        System.out.println("A cor do morcego é " + this.getcorPelo() + ".");
    
    }
/**
 *sobreescrita dos metodos  Animal
 */
    @Override
     public void talk(){
        System.out.print("biosonar.\n");
    }

    /**
     * sobreescrita dos metodos Manifero
     */
    @Override
    public void amamentar(){
        System.out.print("Amentando os filhotes.\n");
    }

    /**
    * método implementado pela classe que sera completa com a entrada dos dados da altitude
    */
    public void AvesVoar() {
        System.out.println("A altitude de voo do morcego é " + this.getAltitude() + " metros.\n");
    }
}
