/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fazendapoo;

/**
 *
 * @author Glau
 */
public  class Pato extends Ave implements Voar {
    
    private int altitude;
    
     public Pato(int idade, double tamanho, String corPena, int altitude) {
        super(idade, tamanho, corPena);
        this.altitude = altitude;
}
     
      /**
     * @return 
     * @ assinaturas getters e setters 
     */
     
     public int getaltitude(){
      return altitude;
     }
     
     public void setaltitude( int altitude){
         this.altitude=altitude;
     
     }
     //metodo atribuido a cada variavel
    public void DadosPato(){
        System.out.println("\n");
        System.out.println("***Novo animal cadastrado com sucesso!***");
        System.out.println("\n");
        System.out.println("A idade do pato é " + this.getIdade() + " anos.");
        System.out.println("O tamanho do pato é " + this.getTamanho() + " centímetros.");
        System.out.println("A cor do pato é " + this.getCorPena() + ".");
    }

    /**
     * sobreescrita dos metodos  
     */
    @Override
    public abstract void talk();
 {
        System.out.print("O pato grasina :quack,quack.\n");
    }

    /**
     * sobreescrita dos metodos  
     */
    @Override
    public void ChocarOvo(){
        System.out.print("Ele botou um ovo.\n");
    }

     /**
     * sobreescrita dos metodos  
     */
    @Override
    public void AvesVoar(){
        System.out.println("A altitude de voo deste pato é " + this.getaltitude() + " metros.\n");
    }
}
