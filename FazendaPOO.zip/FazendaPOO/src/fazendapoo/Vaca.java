/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fazendapoo;

/**
 *
 * @author Glau
 */
public  class Vaca extends Mamifero {
    
     public Vaca(int idade, double tamanho, String corPelo) {
        super(idade, tamanho, corPelo);
     }
     
     
     
    /**
     *metodo utilizado para informar ao usuario as informacoes atribuidas a cada variavel
     */        
    public void DadosVaca(){
        System.out.println("\n");
        System.out.println("***Novo animal cadastrado com sucesso!***");
        System.out.println("\n");
        System.out.println("A idade da vaca é " + this.getIdade() + " anos.");
        System.out.println("O tamanho da vaca é " + this.getTamanho() + " centímetros.");
        System.out.println("A cor da vaca é " + this.getcorPelo() + ".");
    }
   
      /**
     * sobreescrita dos metodos  
     */
     
     @Override
    public void amamentar() {
        
         System.out.print("Amamentando seus filhotes.\n");
    }
           
     /**
     * sobreescrita dos metodos  
     */
     @Override
    public void talk() {
       System.out.print("mugindo\n");
    }

}
    

