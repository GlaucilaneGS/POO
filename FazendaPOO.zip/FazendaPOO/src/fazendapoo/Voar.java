/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fazendapoo;

/**
 *
 * @author Glau
 */
public interface Voar {
  
     /**
     * metodo que invocado pelos animais que voam
     */
    public void AvesVoar();
    
}
